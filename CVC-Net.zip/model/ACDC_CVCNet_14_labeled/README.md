- Download Training model params (通过网盘分享的文件：params
链接: https://pan.baidu.com/s/1AnVkwfxDwR0ZX-tF8Fe06A 提取码: 26re). 

