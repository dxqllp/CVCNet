This fold is used for store models.
