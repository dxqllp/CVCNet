- Download Pancreas-CT dataset(https://www.cancerimagingarchive.net/collection/pancreas-ct/). 

