# The test demo of CVCNet 
1.Download the dataset，please see the introduction data/README.md   
2.Download the trained weight
3.Run python test2d.py  or test3d.py
